<section class="why-choose-section">
    <div class="container">
        <h2 class="section-title text-center">Why Choose CasaGenerators</h2>
        <div class="why-choose-grid">
            <div class="why-card">
                <div class="why-number">01</div>
                <h3 class="why-title">Reliable & Advanced Products</h3>
                <p class="why-text">We fully succeed in Serving, sells and rent all kind of electrical diesel generators in and out UAE specially Iraq as we have a high professional stuff of management, marketing, sells and maintenance services.</p>
            </div>
            <div class="why-card">
                <div class="why-number">02</div>
                <h3 class="why-title">Technical Assistance</h3>
                <p class="why-text">Including material submittal & drawings, supply, testing, commissioning, offloading, installations, load bank test, Annual maintenance contract, service & repair of the generators.</p>
            </div>
            <div class="why-card">
                <div class="why-number">03</div>
                <h3 class="why-title">100% Satisfaction Guarantee</h3>
                <p class="why-text">CASABLANCA offers technical support for all customers at any time anywhere in UAE.We consider this point as a promise to our valued customers.</p>
            </div>
            <div class="why-card">
                <div class="why-number">04</div>
                <h3 class="why-title">Highly Professional Staff</h3>
                <p class="why-text">We are confident our company will meet your requirements, and look forward to doing business with your company.</p>
            </div>
             <div class="why-card">
                <div class="why-number">05</div>
                <h3 class="why-title">Annual Maintenance Contracts</h3>
                <p class="why-text">We offer a one-year standard warranty carried by our highly trained maintenance team of technicians & engineers, as well as entering into Annual Maintenance Contracts (AMC) with our clients.</p>
            </div>
        </div>
    </div>
</section>
