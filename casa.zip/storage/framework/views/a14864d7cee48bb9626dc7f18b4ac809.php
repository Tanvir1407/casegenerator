<header class="main-header">
    <div class="container">
        <nav class="navbar">
            <a href="/" class="logo">
                <img src="<?php echo e(asset('images/Logo/Casagenerators Logo (1).png')); ?>" alt="Casagenerators Logo" class="logo-image">
            </a>
            <ul class="nav-menu">
                <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                <li><a href="<?php echo e(route('products-services')); ?>">Products & Services</a></li>
                <li><a href="<?php echo e(route('blog')); ?>">Blog</a></li>
                <li><a href="<?php echo e(route('awards')); ?>">Awards & Certificates</a></li>
                <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
            </ul>
            <div class="nav-actions">
                <a href="<?php echo e(route('home')); ?>#contact-form" class="btn btn-primary">Request a Quote</a>
                <button class="mobile-menu-toggle" aria-label="Toggle menu">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </nav>
    </div>
</header>

<?php /**PATH /mnt/C8FABDB7FABDA25C/Office/casablanca/casagenerators/resources/views/landing/sections/header.blade.php ENDPATH**/ ?>