<section id="contact-form" class="contact-form-section">
    <div class="contact-background">
        <div class="container">
            <div class="contact-content">
                <div class="contact-badge">
                    <span>Request A Quote</span>
                </div>
                <h2 class="section-title-white">
                                Complete control ensures the best quality, pricing, and service.                </h2>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                    <div style="background-color: #ef4444; color: white; padding: 1rem; margin-bottom: 1rem; border-radius: 0.5rem;">
                        <ul style="margin: 0; padding-left: 1.5rem;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </ul>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                
                <form class="contact-form" action="<?php echo e(route('quote.request.submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <input type="text" name="name" placeholder="Name" value="<?php echo e(old('name')); ?>" required>
                        <input type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                    </div>
                    <div class="form-row">
                        <input type="tel" name="phone" placeholder="Phone" value="<?php echo e(old('phone')); ?>">
                        <select name="industry" class="form-select" required>
                            <option value="" disabled <?php echo e(old('industry') ? '' : 'selected'); ?>>Select your industry</option>
                            <option value="industry_one" <?php echo e(old('industry') == 'industry_one' ? 'selected' : ''); ?>>Industry One</option>
                            <option value="industry_two" <?php echo e(old('industry') == 'industry_two' ? 'selected' : ''); ?>>Industry Two</option>
                            <option value="industry_four" <?php echo e(old('industry') == 'industry_four' ? 'selected' : ''); ?>>Industry Four</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <textarea name="message" rows="4" placeholder="Additional Details!" required><?php echo e(old('message')); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary-black">Submit</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
    <div id="successModal" style="display: flex; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); z-index: 100000; align-items: flex-start; justify-content: center; overflow-y: auto; padding: 1rem; box-sizing: border-box;">
        <div style="background: white; padding: 2rem; border-radius: 1rem; max-width: 400px; width: 100%; text-align: center; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2); animation: slideIn 0.3s ease-out; margin: auto; position: relative;">
            <div style="width: 60px; height: 60px; background-color: #F99C1B; border-radius: 50%; margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center;">
                <svg style="width: 30px; height: 30px; color: white;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                </svg>
            </div>
            <h3 style="color: #1f2937; font-size: 1.5rem; margin-bottom: 0.5rem; font-weight: 600;">Success!</h3>
            <p style="color: #6b7280; margin-bottom: 1.5rem; line-height: 1.6;"><?php echo e(session('success')); ?></p>
            <button onclick="closeModal()" style="background-color: #F99C1B; color: white; padding: 0.75rem 2rem; border: none; border-radius: 0.5rem; font-weight: 600; cursor: pointer; font-size: 1rem; transition: background-color 0.2s;">
                OK
            </button>
        </div>
    </div>

    <style>
        @keyframes slideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>

    <script>
        function closeModal() {
            document.getElementById('successModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        document.getElementById('successModal')?.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    </script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</section>
<?php /**PATH /mnt/C8FABDB7FABDA25C/Office/casablanca/casagenerators/resources/views/landing/sections/contact-form.blade.php ENDPATH**/ ?>