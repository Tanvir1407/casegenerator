<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildSchema()); ?>

</div>
<?php /**PATH /mnt/C8FABDB7FABDA25C/Office/casablanca/casagenerators/vendor/filament/schemas/resources/views/components/grid.blade.php ENDPATH**/ ?>