<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - CasaGenerators</title>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/logo/Casagenerators Logo (1).png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/logo/Casagenerators Logo (1).png')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/logo/Casagenerators Logo (1).png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/landing.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/pages.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <?php echo $__env->make('landing.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->make('pages.blog.sections.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->make('pages.blog.sections.posts-grid', ['posts' => $posts], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    
    <?php echo $__env->make('landing.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <script src="<?php echo e(asset('js/landing.js')); ?>"></script>
</body>
</html>
<?php /**PATH /mnt/C8FABDB7FABDA25C/Office/casablanca/casagenerators/resources/views/pages/blog/index.blade.php ENDPATH**/ ?>