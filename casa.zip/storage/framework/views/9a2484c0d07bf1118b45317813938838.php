<?php
    $partners = [
        '11-300x153-1.webp',
        '172-1723515_john-deere-logo-vector-john-deere-logo-svg-300x204-1.webp',
        '2-5-300x153-1.webp',
        '6-300x153-1.webp',
        '7-300x153-1.webp',
        'Kubota-Logo-300x169-1.webp',
        'WhatsApp-Image-2022-10-14-at-2.59.40-PM-300x181-1.webp',
        'ezgif-3-bc3a810894.webp'
    ];
?>

<section class="partners-section">
    <div class="container featured-header" style="margin-bottom: 40px;">
        
        <h2 class="section-title-center" style="font-size: 36px; margin-bottom: 10px;">Trusted by Industry Leaders</h2>
    </div>
    <div class="partners-container">
        <div class="partners-track">
            <!-- Original Set -->
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="partner-logo">
                    <img src="<?php echo e(asset('images/Partners/' . $partner)); ?>" alt="Partner Logo">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            
            <!-- duplicate Set for smooth infinite scroll -->
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="partner-logo">
                    <img src="<?php echo e(asset('images/Partners/' . $partner)); ?>" alt="Partner Logo">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

             <!-- Triple Set to ensure coverage on wide screens -->
             <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="partner-logo">
                 <img src="<?php echo e(asset('images/Partners/' . $partner)); ?>" alt="Partner Logo">
             </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH /mnt/C8FABDB7FABDA25C/Office/casablanca/casagenerators/resources/views/landing/sections/partners.blade.php ENDPATH**/ ?>