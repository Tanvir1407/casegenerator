<?php

namespace App\Filament\Resources\Posts;

use App\Models\Post;
use Filament\Resources\Resource;
use Filament\Tables\Table;
use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use App\Filament\Components\RichEditor;
use Filament\Forms\Components\FileUpload;
use Illuminate\Support\Str;
use Filament\Tables;
use Filament\Actions\ViewAction;
use Filament\Actions\DeleteAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Components\ImageEntry;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\ViewField;


class PostResource extends Resource
{
    protected static ?string $model = Post::class;

    protected static ?string $navigationLabel = 'Blog';
    
    protected static ?string $modelLabel = 'blog post';
    
    protected static ?string $pluralModelLabel = 'blog posts';

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-document-text';

    /* ===================== FORM ===================== */
    public static function form(Schema $schema): Schema
    {
        return $schema->schema([
            TextInput::make('title')
                ->required()
                ->maxLength(255)
                ->unique('posts', 'title', ignoreRecord: true)
                ->live(onBlur: true)
                ->afterStateUpdated(fn ($state, $set) => 
                    $set('slug', Str::slug($state))
                ),

            TextInput::make('slug')
                ->required()
                ->maxLength(255)
                ->unique('posts', 'slug', ignoreRecord: true),

            FileUpload::make('featured_image')
                ->label('Featured Image')
                ->image()
                ->disk('public')
                ->directory('posts/featured')
                ->visibility('public')
                ->maxSize(5120)
                ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/gif', 'image/webp'])
                ->imageEditor()
                ->imageEditorAspectRatios([
                    '16:9',
                    '4:3',
                    '1:1',
                ])
                ->imageResizeMode('cover')
                ->imageCropAspectRatio('16:9')
                ->imageResizeTargetWidth(1200)
                ->imageResizeTargetHeight(675)
                ->columnSpanFull()
                ->helperText('Upload a high-quality featured image (recommended: 1200x675px, 16:9 ratio)'),

            // RichEditor::make('body')
            //     ->required()
            //     ->columnSpanFull()
            //     ->fileAttachmentsDisk('public')
            //     ->fileAttachmentsDirectory('blog-content')
            //     ->fileAttachmentsVisibility('public'),
            
            

            ViewField::make('body')
                ->view('components.tiny-mce-editor')
                ->columnSpanFull(),

            ]);
        }

    /* ===================== TABLE ===================== */
    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                TextColumn::make('title')
                    ->searchable()
                    ->sortable()
                    ->description(fn (Post $record) =>
                        Str::limit($record->slug, 30)
                    ),
                
                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->actions([
                ViewAction::make(),
                DeleteAction::make(),
            ]);
    }

    /* ===================== INFOLIST ===================== */
    public static function infolist(Schema $schema): Schema
    {
        return $schema
            ->schema([
                Section::make()
                    ->schema([
                        ImageEntry::make('featured_image')
                            ->hiddenLabel()
                            ->disk('public')
                            ->visibility('public')
                            ->width('100%')
                            ->height('auto')
                            ->extraImgAttributes([
                                'class' => 'w-full rounded-lg shadow-md object-cover',
                                'style' => 'max-height: 400px;',
                            ])
                            ->columnSpanFull(),

                        TextEntry::make('title')
                            ->hiddenLabel()
                            ->weight(\Filament\Support\Enums\FontWeight::Bold)
                            ->size(\Filament\Support\Enums\TextSize::Large)
                            ->extraAttributes(['class' => 'text-3xl mt-4'])
                            ->columnSpanFull(),
                            
                        TextEntry::make('created_at')
                            ->hiddenLabel()
                            ->date('F d, Y')
                            ->prefix('Published on ')
                            ->color('gray')
                            ->columnSpanFull(),

                        TextEntry::make('body')
                            ->hiddenLabel()
                            ->html()
                            ->columnSpanFull(),
                    ])->columns(1),
            ]) 
            ->columns(1);
    }

    /* ===================== PAGES ===================== */
    public static function getPages(): array
    {
        return [
            'index'  => \App\Filament\Resources\Posts\Pages\ListPosts::route('/'),
            'create' => \App\Filament\Resources\Posts\Pages\CreatePost::route('/create'),
            'view'   => \App\Filament\Resources\Posts\Pages\ViewPost::route('/{record}'),
            'edit'   => \App\Filament\Resources\Posts\Pages\EditPost::route('/{record}/edit'),
        ];
    }
}
